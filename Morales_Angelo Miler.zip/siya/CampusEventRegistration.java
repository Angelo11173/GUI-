import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CampusEventRegistration extends JFrame {

    // Text fields
    JTextField txtName;
    JTextField txtAge;
    JTextField txtCollege;

    // Combo box
    JComboBox<String> cmbEvent;

    // Radio buttons
    JRadioButton rbParticipant;
    JRadioButton rbAudience;
    JRadioButton rbFaculty;
    ButtonGroup attendanceGroup;

    // Check boxes
    JCheckBox cbJava;
    JCheckBox cbWeb;
    JCheckBox cbCybersecurity;
    JCheckBox cbAI;
    JCheckBox cbDatabase;

    // Text area
    JTextArea txtNotes;

    // Buttons
    JButton btnRegister;
    JButton btnClear;

    public CampusEventRegistration() {

        setTitle("Campus Event Registration System");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // =========================
        // PARTICIPANT NAME
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Participant Name:"), gbc);

        txtName = new JTextField(20);
        gbc.gridx = 1;
        panel.add(txtName, gbc);

        // =========================
        // AGE
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Age:"), gbc);

        txtAge = new JTextField(20);
        gbc.gridx = 1;
        panel.add(txtAge, gbc);

        // =========================
        // COLLEGE / DEPARTMENT
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("College/Department:"), gbc);

        txtCollege = new JTextField(20);
        gbc.gridx = 1;
        panel.add(txtCollege, gbc);

        // =========================
        // EVENT CATEGORY
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Event Category:"), gbc);

        String[] events = {
            "Select Event",
            "Programming Competition",
            "Web Design Challenge",
            "Cybersecurity Seminar",
            "AI and Emerging Technologies",
            "IT Quiz Bowl"
        };

        cmbEvent = new JComboBox<>(events);
        gbc.gridx = 1;
        panel.add(cmbEvent, gbc);

        // =========================
        // ATTENDANCE TYPE
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Attendance Type:"), gbc);

        JPanel attendancePanel = new JPanel();

        rbParticipant = new JRadioButton("Student Participant");
        rbAudience = new JRadioButton("Student Audience");
        rbFaculty = new JRadioButton("Faculty/Staff");

        attendanceGroup = new ButtonGroup();
        attendanceGroup.add(rbParticipant);
        attendanceGroup.add(rbAudience);
        attendanceGroup.add(rbFaculty);

        attendancePanel.add(rbParticipant);
        attendancePanel.add(rbAudience);
        attendancePanel.add(rbFaculty);

        gbc.gridx = 1;
        panel.add(attendancePanel, gbc);

        // =========================
        // WORKSHOPS
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Workshops to Attend:"), gbc);

        JPanel workshopPanel = new JPanel();
        workshopPanel.setLayout(new GridLayout(5, 1));

        cbJava = new JCheckBox("Java Programming");
        cbWeb = new JCheckBox("Web Development");
        cbCybersecurity = new JCheckBox("Cybersecurity");
        cbAI = new JCheckBox("Artificial Intelligence");
        cbDatabase = new JCheckBox("Database Management");

        workshopPanel.add(cbJava);
        workshopPanel.add(cbWeb);
        workshopPanel.add(cbCybersecurity);
        workshopPanel.add(cbAI);
        workshopPanel.add(cbDatabase);

        gbc.gridx = 1;
        panel.add(workshopPanel, gbc);

        // =========================
        // SPECIAL REQUEST / NOTES
        // =========================
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(new JLabel("Special Request/Notes:"), gbc);

        txtNotes = new JTextArea(5, 20);
        txtNotes.setLineWrap(true);
        txtNotes.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(txtNotes);

        gbc.gridx = 1;
        panel.add(scrollPane, gbc);

        // =========================
        // BUTTONS
        // =========================
        JPanel buttonPanel = new JPanel();

        btnRegister = new JButton("REGISTER");
        btnClear = new JButton("CLEAR");

        buttonPanel.add(btnRegister);
        buttonPanel.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        panel.add(buttonPanel, gbc);

        add(panel);

        // REGISTER BUTTON
        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerParticipant();
            }
        });

        // CLEAR BUTTON
        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });
    }

    // ==========================================
    // REGISTER FUNCTION
    // ==========================================
    private void registerParticipant() {

        String name = txtName.getText().trim();
        String ageText = txtAge.getText().trim();
        String college = txtCollege.getText().trim();

        // Check participant name
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Participant Name is required.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            txtName.requestFocus();
            return;
        }

        // Check age empty
        if (ageText.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Age is required.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            txtAge.requestFocus();
            return;
        }

        // Check valid whole number
        int age;

        try {
            age = Integer.parseInt(ageText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Age must be a valid whole number.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            txtAge.requestFocus();
            return;
        }

        // Check age greater than zero
        if (age <= 0) {
            JOptionPane.showMessageDialog(
                this,
                "Age must be greater than zero.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            txtAge.requestFocus();
            return;
        }

        // Check college
        if (college.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "College/Department is required.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            txtCollege.requestFocus();
            return;
        }

        // Check event
        if (cmbEvent.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(
                this,
                "Please select an Event Category.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            cmbEvent.requestFocus();
            return;
        }

        // Check attendance
        if (!rbParticipant.isSelected()
                && !rbAudience.isSelected()
                && !rbFaculty.isSelected()) {

            JOptionPane.showMessageDialog(
                this,
                "Please select an Attendance Type.",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        // Get selected event
        String event = cmbEvent.getSelectedItem().toString();

        // Get attendance type
        String attendance = "";

        if (rbParticipant.isSelected()) {
            attendance = "Student Participant";
        } else if (rbAudience.isSelected()) {
            attendance = "Student Audience";
        } else if (rbFaculty.isSelected()) {
            attendance = "Faculty/Staff";
        }

        // Get workshops
        String workshops = "";

        if (cbJava.isSelected()) {
            workshops += "Java Programming\n";
        }

        if (cbWeb.isSelected()) {
            workshops += "Web Development\n";
        }

        if (cbCybersecurity.isSelected()) {
            workshops += "Cybersecurity\n";
        }

        if (cbAI.isSelected()) {
            workshops += "Artificial Intelligence\n";
        }

        if (cbDatabase.isSelected()) {
            workshops += "Database Management\n";
        }

        if (workshops.isEmpty()) {
            workshops = "None";
        }

        // Get notes
        String notes = txtNotes.getText().trim();

        if (notes.isEmpty()) {
            notes = "None";
        }

        // Registration summary
        String summary =
                "===== REGISTRATION SUMMARY =====\n\n"
                + "Participant Name: " + name + "\n"
                + "Age: " + age + "\n"
                + "College/Department: " + college + "\n"
                + "Event Category: " + event + "\n"
                + "Attendance Type: " + attendance + "\n\n"
                + "Workshops:\n"
                + workshops
                + "\nSpecial Request/Notes:\n"
                + notes;

        JOptionPane.showMessageDialog(
            this,
            summary,
            "Registration Successful",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    // ==========================================
    // CLEAR FUNCTION
    // ==========================================
    private void clearForm() {

        txtName.setText("");
        txtAge.setText("");
        txtCollege.setText("");

        cmbEvent.setSelectedIndex(0);

        attendanceGroup.clearSelection();

        cbJava.setSelected(false);
        cbWeb.setSelected(false);
        cbCybersecurity.setSelected(false);
        cbAI.setSelected(false);
        cbDatabase.setSelected(false);

        txtNotes.setText("");

        txtName.requestFocus();
    }

    // ==========================================
    // MAIN METHOD
    // ==========================================
    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CampusEventRegistration().setVisible(true);
            }
        });
    }
}
